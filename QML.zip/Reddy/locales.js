const translations = {
    en: {
        app_name: "AgriVision",
        login_subtitle: "Smart Crop Intelligence",
        username: "Username",
        mobile: "Mobile Number",
        login_btn: "Login",
        nav_home: "Home",
        nav_predict: "Predict Yield",
        nav_recommend: "Recommendation",
        farmer: "Farmer",
        welcome_title: "Welcome back!",
        welcome_msg: "Your farm analytics are ready.",
        logout_btn: "Logout"
    },
    te: {
        app_name: "అగ్రివిజన్",
        login_subtitle: "స్మార్ట్ పంట మేధస్సు",
        username: "వినియోగదారు పేరు",
        mobile: "మొబైల్ సంఖ్య",
        login_btn: "లాగిన్",
        nav_home: "హోమ్",
        nav_predict: "దిగుబడి అంచనా",
        nav_recommend: "పంట సిఫార్సు",
        farmer: "రైతు",
        welcome_title: "స్వాగతం!",
        welcome_msg: "మీ పంట విశ్లేషణలు సిద్ధంగా ఉన్నాయి.",
        logout_btn: "లాగౌట్"
    },
    ta: {
        app_name: "அக்ரிவிஷன்",
        login_subtitle: "ஸ்மார்ட் பயிர் நுண்ணறிவு",
        username: "பயனர்பெயர்",
        mobile: "கைபேசி எண்",
        login_btn: "உள்நுழைக",
        nav_home: "முகப்பு",
        nav_predict: "மகசூல் கணிப்பு",
        nav_recommend: "பயிர் பரிந்துரை",
        farmer: "விவசாயி",
        welcome_title: "வரவேற்கிறோம்!",
        welcome_msg: "உங்கள் பண்ணை பகுப்பாய்வு தயாராக உள்ளது.",
        logout_btn: "வெளியேறு"
    },
    kn: {
        app_name: "ಅಗ್ರಿವಿಷನ್",
        login_subtitle: "ಸ್ಮಾರ್ಟ್ ಬೆಳೆ ಬುದ್ಧಿಮತ್ತೆ",
        username: "ಬಳಕೆದಾರರ ಹೆಸರು",
        mobile: "ಮೊಬೈಲ್ ಸಂಖ್ಯೆ",
        login_btn: "ಲಾಗಿನ್",
        nav_home: "ಮುಖಪುಟ",
        nav_predict: "ಇಳುವರಿ ಮುನ್ಸೂಚನೆ",
        nav_recommend: "ಬೆಳೆ ಶಿಫಾರಸು",
        farmer: "ರೈತ",
        welcome_title: "ಸ್ವಾಗತ!",
        welcome_msg: "ನಿಮ್ಮ ಫಾರ್ಮ್ ವಿಶ್ಲೇಷಣೆ ಸಿದ್ಧವಾಗಿದೆ.",
        logout_btn: "ಲಾಗ್‌ಔಟ್"
    }
};
