import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.preprocessing import LabelEncoder
import joblib
import json

# Configuration
DATA_SIZE = 5000
RANDOM_SEED = 42

# Synthetic Data Generators
def generate_data(n_samples):
    np.random.seed(RANDOM_SEED)
    
    # States and their typical characteristics (Simplified)
    states = ['Andhra Pradesh', 'Telangana', 'Tamil Nadu', 'Karnataka', 'Maharashtra']
    seasons = ['Kharif', 'Rabi', 'Whole Year']
    crops = ['Rice', 'Maize', 'Cotton', 'Groundnut', 'Sugarcane', 'Wheat']
    
    data = {
        'State': np.random.choice(states, n_samples),
        'Crop_Year': np.random.randint(2010, 2024, n_samples),
        'Season': np.random.choice(seasons, n_samples),
        'Crop': np.random.choice(crops, n_samples),
        'Area': np.random.uniform(1, 100, n_samples).round(2), # Hectares
        'Rainfall': np.random.uniform(500, 2500, n_samples).round(1), # mm
        'Temperature': np.random.uniform(20, 35, n_samples).round(1), # Celsius
        'Pesticide': np.random.uniform(0, 100, n_samples).round(2), # kg/ha
    }
    
    df = pd.DataFrame(data)
    
    # Generate Target (Yield) with some logical relationships
    # Base yield + factors
    def calculate_yield(row):
        base = 2.0 # tonnes/hectare
        
        # Crop specific adjustments
        if row['Crop'] == 'Sugarcane': base = 60.0
        elif row['Crop'] == 'Rice': base = 4.0
        elif row['Crop'] == 'Cotton': base = 1.5
        elif row['Crop'] == 'Maize': base = 3.5
        
        # Rain factor (Ideal ~1500 for water intensive, else ~800)
        rain_diff = abs(row['Rainfall'] - 1200)
        rain_penalty = rain_diff * 0.001
        
        # Temp factor (Ideal 25-30)
        temp_diff = abs(row['Temperature'] - 28)
        temp_penalty = temp_diff * 0.1
        
        # Pesticide benefit (diminishing returns)
        pest_benefit = np.log1p(row['Pesticide']) * 0.1
        
        final_yield = base - rain_penalty - temp_penalty + pest_benefit + np.random.normal(0, 0.2)
        return max(0.1, round(final_yield, 2))

    df['Yield'] = df.apply(calculate_yield, axis=1)
    df['Production'] = (df['Area'] * df['Yield']).round(2)
    
    return df

def train_model():
    print("Generating synthetic data...")
    df = generate_data(DATA_SIZE)
    
    # Save raw data
    df.to_csv('./data/synthetic_crop_data.csv', index=False)
    print("Data saved to data/synthetic_crop_data.csv")
    
    # Preprocessing
    le_state = LabelEncoder()
    le_season = LabelEncoder()
    le_crop = LabelEncoder()
    
    df['State_Encoded'] = le_state.fit_transform(df['State'])
    df['Season_Encoded'] = le_season.fit_transform(df['Season'])
    df['Crop_Encoded'] = le_crop.fit_transform(df['Crop'])
    
    features = ['State_Encoded', 'Season_Encoded', 'Crop_Encoded', 'Area', 'Rainfall', 'Temperature', 'Pesticide']
    target = 'Yield' # Predicting Yield (Tonnes/Hectare)
    
    X = df[features]
    y = df[target]
    
    print("Training Random Forest Regressor...")
    model = RandomForestRegressor(n_estimators=100, random_state=RANDOM_SEED)
    model.fit(X, y)
    
    # Save artifacts
    artifacts = {
        'model': model,
        'encoders': {
            'State': le_state,
            'Season': le_season,
            'Crop': le_crop
        }
    }
    
    joblib.dump(artifacts, './models/crop_yield_model.pkl')
    
    # Save mappings for frontend
    mappings = {
        'State': list(le_state.classes_),
        'Season': list(le_season.classes_),
        'Crop': list(le_crop.classes_)
    }
    with open('./models/mappings.json', 'w') as f:
        json.dump(mappings, f, indent=2)
        
    print("Model and artifacts saved to models/")

if __name__ == "__main__":
    train_model()
