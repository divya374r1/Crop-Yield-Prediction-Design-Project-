// State
const state = {
    user: null,
    lang: 'en',
    map: null,
    points: [],
    polygon: null,
    markers: [],
    measuredArea: 0 // Acres
};

// DOM Elements
const views = {
    auth: document.getElementById('auth-view'),
    dashboard: document.getElementById('dashboard-view'),
    tabs: {
        home: document.getElementById('tab-home'),
        map: document.getElementById('tab-map'),
        predict: document.getElementById('tab-predict'),
        fertilizer: document.getElementById('tab-fertilizer')
    }
};

const loginForm = document.getElementById('loginForm');
const langSelect = document.getElementById('langSelect');
const logoutBtn = document.getElementById('logoutBtn');
const displayUsername = document.getElementById('display-username');
const navLinks = document.querySelectorAll('.nav-links li');
const forms = {
    predict: document.getElementById('predictForm'),
    fertilizer: document.getElementById('fertilizerForm')
};

// Initialization
document.addEventListener('DOMContentLoaded', () => {
    // Check local storage for user
    const savedUser = localStorage.getItem('agrivision_user');
    if (savedUser) {
        state.user = JSON.parse(savedUser);
        showDashboard();
    } else {
        showAuth();
    }

    // Check language
    const savedLang = localStorage.getItem('agrivision_lang') || 'en';
    state.lang = savedLang;
    langSelect.value = savedLang;
    applyLanguage(savedLang);
});

// Event Listeners
langSelect.addEventListener('change', (e) => {
    const newLang = e.target.value;
    state.lang = newLang;
    localStorage.setItem('agrivision_lang', newLang);
    applyLanguage(newLang);
});

loginForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const username = document.getElementById('username').value;
    const mobile = document.getElementById('mobile').value;

    // Simple validation
    if (username.length < 3 || mobile.length < 10) {
        alert('Please enter valid details');
        return;
    }

    state.user = { username, mobile };
    localStorage.setItem('agrivision_user', JSON.stringify(state.user));
    showDashboard();
});

logoutBtn.addEventListener('click', () => {
    state.user = null;
    localStorage.removeItem('agrivision_user');
    showAuth();
});

// Navigation Logic
navLinks.forEach(link => {
    link.addEventListener('click', () => {
        navLinks.forEach(l => l.classList.remove('active'));
        link.classList.add('active');

        Object.values(views.tabs).forEach(tab => {
            tab.classList.add('hidden');
            tab.classList.remove('active');
        });

        const target = link.getAttribute('data-tab');
        if (views.tabs[target]) {
            views.tabs[target].classList.remove('hidden');
            views.tabs[target].classList.add('active');

            if (target === 'map') {
                setTimeout(initMap, 200); // Delay refresh to handle layout bounds
            }
        }
    });
});

// Map Logic
let satelliteLayer, streetLayer;

function initMap() {
    if (state.map) {
        state.map.invalidateSize();
        return;
    }

    // Define Layers
    streetLayer = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '© OpenStreetMap contributors'
    });

    satelliteLayer = L.tileLayer('https://mt1.google.com/vt/lyrs=s&x={x}&y={y}&z={z}', {
        attribution: '© Google Satellite'
    });

    // Default to a central India location or user's preference
    state.map = L.map('map-container', {
        center: [17.3850, 78.4867],
        zoom: 13,
        layers: [streetLayer] // Start with street view
    });

    // Click handler for polygon drawing
    state.map.on('click', (e) => {
        const { lat, lng } = e.latlng;

        // Add Marker
        const marker = L.marker([lat, lng]).addTo(state.map);
        state.markers.push(marker);
        state.points.push([lat, lng]);

        // Draw Polygon
        if (state.polygon) state.map.removeLayer(state.polygon);

        if (state.points.length > 1) {
            state.polygon = L.polygon(state.points, { color: '#10B981' }).addTo(state.map);
        }

        // Close polygon if clicked near first point (simple logic: auto close if > 2 points)
        if (state.points.length > 2) {
            calculateArea(state.points);
        }
    });
}

document.getElementById('satelliteToggleBtn').addEventListener('click', (e) => {
    if (state.map.hasLayer(streetLayer)) {
        state.map.removeLayer(streetLayer);
        state.map.addLayer(satelliteLayer);
        e.target.textContent = 'Street View';
    } else {
        state.map.removeLayer(satelliteLayer);
        state.map.addLayer(streetLayer);
        e.target.textContent = 'Satellite View';
    }
});

document.getElementById('resetMapBtn').addEventListener('click', () => {
    state.points = [];
    state.markers.forEach(m => state.map.removeLayer(m));
    state.markers = [];
    if (state.polygon) state.map.removeLayer(state.polygon);
    state.polygon = null;
    state.measuredArea = 0;
    document.getElementById('area-display').textContent = '0 Acres';
});

document.getElementById('useAreaBtn').addEventListener('click', () => {
    if (state.measuredArea > 0) {
        document.getElementById('pred-area').value = state.measuredArea.toFixed(2);
        document.getElementById('fert-area').value = state.measuredArea.toFixed(2);
        alert(`Area of ${state.measuredArea.toFixed(2)} Acres saved for calculations!`);
    } else {
        alert("Please mark an area on the map first.");
    }
});

// Global Location Change
const globalLocationSelect = document.getElementById('global-location');
if (globalLocationSelect) {
    globalLocationSelect.addEventListener('change', (e) => {
        alert(`Region changed to ${e.target.value}. Predictions will now use ${e.target.value} data.`);
    });
}

// Simple Area Calculation (Shoelace Formula approximation for small areas)
function calculateArea(coords) {
    // This is a rough estimation. For production, use L.GeometryUtil.geodesicArea
    // Converting lat/lng to meters roughly
    const R = 6378137; // Earth radius in meters
    let area = 0;

    if (coords.length < 3) return;

    for (let i = 0; i < coords.length; i++) {
        const p1 = coords[i];
        const p2 = coords[(i + 1) % coords.length];

        const x1 = p1[1] * (Math.PI / 180) * R * Math.cos(p1[0] * Math.PI / 180);
        const y1 = p1[0] * (Math.PI / 180) * R;

        const x2 = p2[1] * (Math.PI / 180) * R * Math.cos(p2[0] * Math.PI / 180);
        const y2 = p2[0] * (Math.PI / 180) * R;

        area += (x1 * y2) - (x2 * y1);
    }

    area = Math.abs(area / 2); // Area in sq meters
    const acres = area * 0.000247105; // Convert to Acres
    state.measuredArea = acres;
    document.getElementById('area-display').textContent = acres.toFixed(2) + ' Acres';
}


// Mode Toggle Logic
const modeSwitch = document.getElementById('mode-switch');
const modeText = document.getElementById('mode-text');
const easyFields = document.getElementById('easy-fields');
const advancedFields = document.getElementById('advanced-fields');

if (modeSwitch) {
    modeSwitch.addEventListener('change', (e) => {
        if (e.target.checked) {
            modeText.textContent = 'Easy Mode';
            easyFields.classList.remove('hidden');
            advancedFields.classList.add('hidden');
        } else {
            modeText.textContent = 'Advanced Mode';
            easyFields.classList.add('hidden');
            advancedFields.classList.remove('hidden');
        }
    });
}

// Form Submissions
forms.predict.addEventListener('submit', (e) => {
    e.preventDefault();
    const btn = e.target.querySelector('button');
    const originalText = btn.textContent;
    btn.textContent = 'Analyzing...';

    const formData = new FormData(e.target);
    const rawData = Object.fromEntries(formData.entries());

    let submitData = { ...rawData };

    // If Easy Mode is active, populate technical values
    if (modeSwitch.checked) {
        // Soil Quality Mapping
        const soilMaps = {
            poor: { N: 30, P: 20, K: 15, ph: 5.8 },
            medium: { N: 60, P: 40, K: 30, ph: 6.5 },
            good: { N: 100, P: 60, K: 50, ph: 7.2 }
        };
        const soil = soilMaps[rawData.soil_quality] || soilMaps.medium;

        // Season Mapping
        const seasonMaps = {
            Kharif: { temperature: 30, humidity: 80, rainfall: 1200 },
            Rabi: { temperature: 22, humidity: 45, rainfall: 150 },
            Summer: { temperature: 36, humidity: 30, rainfall: 50 }
        };
        let weather = { ...(seasonMaps[rawData.season] || seasonMaps.Kharif) };

        // Adjust for Weather Condition
        if (rawData.weather_condition === 'hot') weather.temperature += 6;
        if (rawData.weather_condition === 'drought') weather.rainfall *= 0.2;
        if (rawData.weather_condition === 'heavy_rain') weather.rainfall *= 2.5;

        // Global Location Adjustment
        const globalLoc = document.getElementById('global-location').value;
        let locationMultiplier = 1.0;
        if (globalLoc === 'Andhra Pradesh' && rawData.selected_crop === 'Rice') locationMultiplier = 1.15;
        if (globalLoc === 'Tamil Nadu' && rawData.selected_crop === 'Sugarcane') locationMultiplier = 1.2;

        submitData = {
            area: parseFloat(rawData.area),
            crop: rawData.selected_crop,
            location: globalLoc,
            N: soil.N,
            P: soil.P,
            K: soil.K,
            ph: soil.ph,
            temperature: weather.temperature,
            humidity: weather.humidity,
            rainfall: weather.rainfall
        };
    } else {
        // Advanced mode: ensure types are correct
        submitData = {
            area: parseFloat(rawData.area),
            N: parseFloat(rawData.N),
            P: parseFloat(rawData.P),
            K: parseFloat(rawData.K),
            temperature: parseFloat(rawData.temperature),
            humidity: parseFloat(rawData.humidity),
            ph: parseFloat(rawData.ph),
            rainfall: parseFloat(rawData.rainfall)
        };
    }

    fetch('http://localhost:8000/predict-yield', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(submitData)
    })
        .then(res => res.json())
        .then(resData => {
            document.getElementById('prediction-result').classList.remove('hidden');
            const resultSpan = document.querySelector('#prediction-result h4 span');

            // Apply location multiplier to the backend result for demo accuracy
            const easyModeMultiplier = modeSwitch.checked ? (1.0) : 1.0; // Placeholders
            const finalYield = resData.total_yield;

            resultSpan.textContent = finalYield + ' Quintals';

            // Highlight based on yield
            if (resData.yield_per_acre > 30) {
                resultSpan.className = 'highlight text-good';
            } else {
                resultSpan.className = 'highlight';
            }
        })
        .catch(err => {
            console.error(err);
            alert("Error connecting to backend server. Make sure main.py is running!");
        })
        .finally(() => btn.textContent = originalText);
});

forms.fertilizer.addEventListener('submit', (e) => {
    e.preventDefault();
    const btn = e.target.querySelector('button');
    const originalText = btn.textContent;
    btn.textContent = 'Calculating...';

    const formData = new FormData(e.target);
    const data = Object.fromEntries(formData.entries());

    fetch('http://localhost:8000/calculate-fertilizer', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
    })
        .then(res => res.json())
        .then(resData => {
            document.getElementById('fertilizer-result').classList.remove('hidden');
            const list = document.getElementById('fert-list');
            list.innerHTML = resData.fertilizers.map(f =>
                `<div class="card" style="padding:10px; background:rgba(255,255,255,0.05);">
                <strong>${f.name}</strong>: ${f.quantity}
                <p style="font-size:0.8rem; color:#aaa;">${f.reason}</p>
             </div>`
            ).join('');
        })
        .catch(console.error)
        .finally(() => btn.textContent = originalText);
});


// Functions
function showAuth() {
    views.dashboard.classList.add('hidden');
    views.dashboard.classList.remove('active');

    views.auth.classList.remove('hidden');
    views.auth.classList.add('active');
}

function showDashboard() {
    views.auth.classList.add('hidden');
    views.auth.classList.remove('active');

    views.dashboard.classList.remove('hidden');
    views.dashboard.classList.add('active');

    displayUsername.textContent = state.user.username;
    setTimeout(initChart, 100);
}

function initChart() {
    const ctx = document.getElementById('yieldChart');
    if (ctx && !window.myYieldChart) {
        window.myYieldChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ['2020', '2021', '2022', '2023', '2024'],
                datasets: [{
                    label: 'Yield (Quintals/Acre)',
                    data: [35, 38, 40, 42, 45],
                    backgroundColor: 'rgba(16, 185, 129, 0.5)',
                    borderColor: '#10B981',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        grid: { color: 'rgba(255,255,255,0.1)' },
                        ticks: { color: '#94A3B8' }
                    },
                    x: { grid: { display: false }, ticks: { color: '#94A3B8' } }
                }
            }
        });
    }
}

function applyLanguage(lang) {
    const t = translations[lang];
    if (!t) return;
    document.querySelectorAll('[data-i18n]').forEach(el => {
        const key = el.getAttribute('data-i18n');
        if (t[key]) el.textContent = t[key];
    });
}
