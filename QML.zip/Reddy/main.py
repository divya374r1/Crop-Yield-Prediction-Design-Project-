from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from fastapi.middleware.cors import CORSMiddleware
import random

app = FastAPI()

# Input Schemas
class PredictionInput(BaseModel):
    area: float
    N: float
    P: float
    K: float
    temperature: float
    humidity: float
    ph: float
    rainfall: float

class FertilizerInput(BaseModel):
    area: float
    crop: str
    soil: str

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/")
def read_root():
    return {"status": "AgriVision Backend is running"}

@app.post("/predict-yield")
def predict_yield(data: PredictionInput):
    # Logic: simple weighted sum + area factor
    base_yield_per_acre = (data.N * 0.5) + (data.P * 0.3) + (data.K * 0.2)
    predicted_yield_per_acre = base_yield_per_acre / 10 + 20 + random.uniform(-2, 2)
    
    total = predicted_yield_per_acre * data.area

    return {
        "yield_per_acre": round(predicted_yield_per_acre, 2),
        "total_yield": round(total, 2),
        "unit": "Quintals"
    }

@app.post("/calculate-fertilizer")
def calculate_fertilizer(data: FertilizerInput):
    # Standard NPK recommendations (simplified)
    # Urea (46% N), SSP (16% P), MOP (60% K)
    
    recs = []
    area = data.area
    
    if data.crop == "Rice":
        # Recommendation: 120-60-40 kg/ha -> ~ 48-24-16 kg/acre NPK
        urea = (48 / 0.46) * area
        ssp = (24 / 0.16) * area
        mop = (16 / 0.60) * area
        recs.append({"name": "Urea", "quantity": f"{round(urea, 1)} Kg", "reason": "Provides Nitrogen for leaf growth"})
        recs.append({"name": "SSP (Single Super Phosphate)", "quantity": f"{round(ssp, 1)} Kg", "reason": "Root development"})
        recs.append({"name": "MOP (Muriate of Potash)", "quantity": f"{round(mop, 1)} Kg", "reason": "Disease resistance"})
        
    elif data.crop == "Cotton":
         # Recommendation: 150-60-60 kg/ha
        urea = (60 / 0.46) * area
        recs.append({"name": "Urea", "quantity": f"{round(urea, 1)} Kg", "reason": "Basic nitrogen requirement"})
        recs.append({"name": "DAP", "quantity": f"{round(20 * area, 1)} Kg", "reason": "Phosphorous boost"})
    
    else:
        # Generic
        recs.append({"name": "N-P-K 20:20:20", "quantity": f"{round(50 * area, 1)} Kg", "reason": "Balanced nutrition"})
        recs.append({"name": "Compost", "quantity": f"{round(2 * area, 1)} Tons", "reason": "Improve soil structure"})
        
    return {
        "fertilizers": recs,
        "input_area": area
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
